# Chapter 4: Cloud Storage Service

Welcome back! In [Chapter 3: PDF Generation Service](03_pdf_generation_service_.md), we saw how our service magically transforms HTML content into a raw PDF data buffer. That's a great step! But what do we do with this PDF data? Just having it in the server's memory isn't very useful if we want users to download it or access it later. We need a safe and reliable place to store it and a way to share it.

That's where our **Cloud Storage Service** comes to the rescue!

## What's the Big Deal? Storing and Sharing Your PDFs Securely

Imagine our `html-to-pdf-service` has just created a PDF for a user – maybe an important invoice or a report.
*   Where does this PDF file go? We can't just keep it on the server's temporary memory forever.
*   How can the user download this specific PDF without getting access to everyone else's PDFs?
*   How do we make sure the link to download the PDF doesn't stay active forever, potentially becoming a security risk?

The **Cloud Storage Service** solves these problems. Its main job is to take the generated PDF data, store it in a secure and highly available online "vault," and then create a special, temporary web link that allows only authorized people to download the PDF for a short time.

Think of it like a super-efficient digital librarian. You hand it a newly printed book (the PDF data). The librarian:
1.  Finds a unique spot on a very secure shelf in a massive library (uploads to Cloud Storage).
2.  Gives you a special, temporary library card (a signed URL) that only lets you borrow that specific book for a limited time.

This way, your PDFs are stored safely, and access is controlled.

## Key Concepts: Your Digital Vault and Secure Links

Let's break down the main ideas:

1.  **Google Cloud Storage (GCS) - The Digital Vault:**
    *   This is a service provided by Google Cloud for storing and retrieving any amount of data. It's designed to be extremely reliable (your files are safe from being lost) and scalable (it can handle lots of files and lots of requests).
    *   **Analogy:** GCS is like a massive, ultra-secure digital bank vault. You can store your valuable digital items (like PDFs) there.

2.  **Bucket - Your Personal Folder in the Vault:**
    *   Inside GCS, you organize your files into "buckets." A bucket is like a top-level folder or a specific safe deposit box within the vault. Our service will have a designated bucket to store all the generated PDFs.
    *   **Analogy:** If GCS is the bank vault, a bucket is your specific, named drawer or container within that vault.

3.  **Uploading - Placing the PDF in the Bucket:**
    *   This is the process of taking the PDF data (the `pdfBuffer` we got from the [PDF Generation Service](03_pdf_generation_service_.md)) and sending it to be stored in our GCS bucket.
    *   **Analogy:** This is like taking your document and physically placing it inside your folder in the vault.

4.  **Signed URL - The Temporary, Secure Web Link:**
    *   Once the PDF is uploaded, we don't want to give everyone a permanent, public link to it. Instead, GCS allows us to create a "signed URL."
    *   This is a special kind of web link that has a built-in permission slip and an expiry date.
    *   Only someone with this exact link can access the file, and the link automatically stops working after a set period (e.g., 5 minutes, an hour).
    *   **Analogy:** A signed URL is like a special, time-limited guest pass to view a specific item in a museum. The pass has your name (figuratively) and an expiry time.

## How It Works: From PDF Data to Download Link

Let's trace the journey after the PDF data (`pdfBuffer`) is generated:

1.  The `pdfController` (from [Chapter 2: Request Routing & Controllers](02_request_routing___controllers_.md)) has the `pdfBuffer`.
2.  It calls a function in our `StorageService`, say `uploadFile(pdfBuffer)`.
3.  The `StorageService` then:
    *   Generates a unique name for the PDF file (so it doesn't overwrite other files).
    *   Uploads the `pdfBuffer` to our designated "bucket" in Google Cloud Storage.
    *   Asks GCS to create a signed URL for this newly uploaded file, specifying how long the URL should be valid.
4.  The `StorageService` returns information about the uploaded file, including the precious signed URL, back to the `pdfController`.
5.  The `pdfController` can then send this signed URL back to the user, who can click it to download their PDF.

### Using the Storage Service (Controller's View)

Let's see how the `pdfController` (from `src/controllers/pdfController.js`) uses the `StorageService`. This builds upon what we saw in Chapter 3.

```javascript
// --- File: src/controllers/pdfController.js (simplified snippet) ---
const pdfService = require('../services/pdfService');
const storageService = require('../services/storageService'); // 1. Import service
// ... logger

exports.convertToPdf = async (req, res, next) => {
  try {
    const { input /* ...other options... */ } = req.body;
    const pdfBuffer = await pdfService.generatePdf(input, { /* ... */ });

    // 2. Call storage service to upload and get URL
    const fileInfo = await storageService.uploadFile(pdfBuffer);

    // 3. Send the secure URL back to the user
    res.json({
      success: true,
      url: fileInfo.url, // This is the signed URL!
      metadata: { filename: fileInfo.filename, /* ... */ }
    });
  } catch (error) {
    next(error);
  }
};
```
1.  **`require('../services/storageService')`**: We import our `StorageService`.
2.  **`const fileInfo = await storageService.uploadFile(pdfBuffer);`**:
    *   The controller takes the `pdfBuffer` (the raw PDF data from `pdfService`) and passes it to `storageService.uploadFile()`.
    *   The `await` means the controller waits for the storage service to finish uploading and generating the link.
    *   `fileInfo` will be an object containing details like the `url` (the signed URL), `filename`, `size`, and `expiresAt`.
3.  **`res.json({ ... url: fileInfo.url ... })`**: The controller sends a JSON response back to the user, including the `fileInfo.url`. The user can now use this URL to download their PDF.

**Input:** The `pdfBuffer` (raw PDF data).
**Output (from `storageService.uploadFile`):** An object like:
```json
{
  "url": "https://storage.googleapis.com/your-bucket-name/pdf/1678886400000-randomstring.pdf?Signature=...",
  "filename": "pdf/1678886400000-randomstring.pdf",
  "expiresAt": "2023-03-15T12:05:00.000Z",
  "size": 12345 // size in bytes
}
```
The `url` is the key piece – it's the temporary, secure link to the PDF.

## Under the Hood: Talking to Google Cloud Storage

So, what happens inside `storageService.uploadFile()`? It involves connecting to Google Cloud Storage, sending the file, and then asking for a signed URL.

Let's visualize the internal flow:

```mermaid
sequenceDiagram
    participant Controller
    participant StorageService
    participant GCS as Google Cloud Storage

    Controller->>StorageService: uploadFile(pdfBuffer)
    StorageService->>StorageService: generateUniqueFilename()
    StorageService->>GCS: Upload PDF buffer (to bucket/filename)
    GCS-->>StorageService: Upload successful
    StorageService->>GCS: Request signed URL for filename
    GCS-->>StorageService: Return signed URL
    StorageService-->>Controller: Return {url, filename, expiresAt, size}
```

Now, let's look at simplified snippets from `src/services/storageService.js`:

**1. Setting up the Connection (Constructor):**
When our `StorageService` is first created, it needs to know how to talk to Google Cloud Storage. This is set up in its `constructor`.

```javascript
// --- File: src/services/storageService.js (constructor snippet) ---
const { Storage } = require('@google-cloud/storage');
const config = require('../config/config'); // Loads GCS_BUCKET_NAME etc.

class StorageService {
  constructor() {
    this.storage = new Storage({ // 1. Initialize GCS library
      projectId: config.gcs.projectId,
      keyFilename: config.gcs.keyFilename // Path to secret key file
    });
    this.bucket = this.storage.bucket(config.gcs.bucketName); // 2. Select bucket
  }
  // ... other methods
}
```
1.  `new Storage(...)`: This creates an object that knows how to communicate with GCS. It uses `projectId` and `keyFilename` (a path to a special secret file that proves our identity to Google Cloud) from our [Configuration Management](06_configuration_management_.md).
2.  `this.storage.bucket(...)`: This tells our service which specific "bucket" (folder) in GCS we'll be working with. The bucket name also comes from our configuration.

**2. Generating a Unique Filename:**
We don't want every PDF to be named `output.pdf`, as new files would overwrite old ones. So, we generate a unique name.

```javascript
// --- File: src/services/storageService.js (filename snippet) ---
const crypto = require('crypto'); // For generating random strings

class StorageService {
  // ... constructor ...
  generateUniqueFilename() {
    const timestamp = Date.now(); // Current time
    const randomString = crypto.randomBytes(8).toString('hex'); // Random part
    return `pdf/${timestamp}-${randomString}.pdf`; // e.g., pdf/16123456789-abcdef1234567890.pdf
  }
  // ... other methods
}
```
This function creates a filename using the current time (`timestamp`) and a random string. This makes it highly unlikely that two files will ever get the same name. The `pdf/` prefix helps organize files within the bucket.

**3. Uploading the File and Getting the Signed URL (`uploadFile` method):**
This is the main method called by the controller.

```javascript
// --- File: src/services/storageService.js (uploadFile snippet) ---
class StorageService {
  // ... constructor and generateUniqueFilename ...

  async uploadFile(buffer) {
    const filename = this.generateUniqueFilename(); // 1. Get unique name
    const file = this.bucket.file(filename);      // 2. Reference to GCS file

    // 3. Upload the buffer (simplified)
    await file.save(buffer, { contentType: 'application/pdf' });
    logger.info(`Uploaded ${filename} to GCS.`);

    // 4. Generate the signed URL for download
    const signedUrl = await this.generateSignedUrl(filename);
    const expiresAt = new Date(Date.now() + (5 * 60 * 1000)); // 5 mins from now

    return { url: signedUrl, filename, expiresAt, size: buffer.length };
  }
  // ... generateSignedUrl method below ...
}
```
1.  `const filename = this.generateUniqueFilename();`: First, get a unique name for our PDF.
2.  `const file = this.bucket.file(filename);`: This creates a reference to a file object within our GCS bucket. It doesn't upload anything yet, just says "this is the file I'm going to work with."
3.  `await file.save(buffer, { contentType: 'application/pdf' });`: This is the actual upload! The `buffer` (our PDF data) is sent to GCS and saved with the unique `filename`. We also tell GCS the `contentType` is `application/pdf` so browsers know how to handle it. (The actual project uses `file.createWriteStream` for more robust uploads, but `file.save` is simpler for illustration).
4.  `const signedUrl = await this.generateSignedUrl(filename);`: After successful upload, we call another helper method (see below) to get the temporary download link. We also calculate when this link will expire.

**4. Generating the Signed URL (`generateSignedUrl` method):**
This method asks GCS to create the special, time-limited download link.

```javascript
// --- File: src/services/storageService.js (generateSignedUrl snippet) ---
class StorageService {
  // ... other methods ...

  async generateSignedUrl(filename) {
    const options = {
      version: 'v4', // GCS signing version
      action: 'read', // We want to allow downloading (reading)
      expires: Date.now() + (5 * 60 * 1000), // Link valid for 5 minutes
    };

    const [signedUrl] = await this.bucket.file(filename).getSignedUrl(options);
    logger.info(`Generated signed URL for ${filename}`);
    return signedUrl;
  }
}
module.exports = new StorageService(); // Export an instance
```
*   `options`: We tell GCS what kind of URL we want:
    *   `version: 'v4'`: The recommended signing version.
    *   `action: 'read'`: The URL should allow users to read (download) the file.
    *   `expires: Date.now() + (5 * 60 * 1000)`: This is crucial! It sets the expiry time for the URL. Here, it's 5 minutes from the current time. After 5 minutes, the link will no longer work. This duration comes from our [Configuration Management](06_configuration_management_.md) in the actual project (`config.redis.ttl` is used as a general TTL, but for signed URLs, it's often a fixed short duration or configurable separately).
*   `this.bucket.file(filename).getSignedUrl(options)`: This is the command to GCS to generate the signed URL for the specified file with our options.
*   It returns the `signedUrl`, which is then passed back up to the `uploadFile` method and eventually to the user.

And that's it! The PDF is now safely stored, and the user has a temporary, secure link to download it.

## Conclusion

You've now learned how the **Cloud Storage Service** plays a vital role in our `html-to-pdf-service`:
*   It takes the generated PDF data (the `pdfBuffer`).
*   It uploads this data to a secure and reliable "digital vault" (Google Cloud Storage) in a designated "bucket."
*   It generates a unique, temporary, and secure "signed URL" that allows authorized users to download the PDF for a limited time.

This service ensures that our generated PDFs are not just created but are also stored properly and made accessible in a controlled manner. This is essential for a production-ready application.

But what if many users request the exact same PDF (e.g., converting the same popular webpage)? Generating it and uploading it every single time can be inefficient. Is there a way to speed things up by remembering recent results? Yes, there is!

In the next chapter, we'll explore how we can use a [Chapter 5: Caching Service](05_caching_service_.md) to store frequently accessed PDFs temporarily for even faster delivery.

---

Generated By NOVA