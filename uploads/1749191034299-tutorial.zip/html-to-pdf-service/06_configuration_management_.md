# Chapter 6: Configuration Management

Welcome! In the previous chapters, like [Chapter 5: Caching Service](05_caching_service_.md), you might have noticed references to things like `config.redis.url` or `config.redis.ttl`. Where do these settings come from? How does our application know which Redis server to connect to, or how long to keep items in the cache? What if we want to run our service on port 3000 for development but port 8080 in production?

This is where **Configuration Management** comes in. It's like the main control panel for our `html-to-pdf-service`.

## What's the Big Deal? The Application's Control Panel

Imagine you're building a complex machine, like our `html-to-pdf-service`. This machine needs various settings to work correctly:
*   Which network port should it listen on for requests? (e.g., 3000, 8080)
*   What's the address of the Redis server for [Caching Service](05_caching_service_.md)?
*   What are the secret credentials to connect to the [Cloud Storage Service](04_cloud_storage_service_.md)?
*   Are we running in "development" mode (with extra debugging) or "production" mode (optimized for performance)?

If we wrote these values directly into our code (hardcoding), it would be a nightmare!
*   **Changing settings:** We'd have to find and change the code every time.
*   **Security:** Putting secret API keys directly in code is a huge security risk, especially if the code is shared.
*   **Different environments:** Our development setup might use a local Redis, while production uses a powerful cloud Redis. The code would need to change for each.

**Configuration Management** solves this by centralizing all these settings. It allows us to manage them (often via environment variables or a special `.env` file) *without* changing the actual application code. This makes our application flexible, secure, and easier to maintain.

## Key Concepts: The Settings and How We Handle Them

1.  **Configuration Settings:**
    *   These are all the values our application needs that might change depending on where or how it's running.
    *   Examples: Server port, database URLs, API keys, feature flags (on/off switches for features), log levels.
    *   **Analogy:** Think of the settings menu in a video game. You can change graphics quality, sound volume, or control schemes without reprogramming the game itself.

2.  **Centralization (The Control Panel):**
    *   Instead of scattering settings throughout the code, we gather them in one place or access them through a single, consistent mechanism.
    *   In our project, this is mainly handled by the `src/config/config.js` file.
    *   **Analogy:** Your car's dashboard. All important controls and indicators are in one place, not hidden under the seats or in the trunk.

3.  **Environment Variables (External Instructions):**
    *   These are variables set *outside* of your application, in the environment where your application runs (e.g., your computer's operating system, a Docker container, a cloud platform).
    *   Your application can then read these variables at startup.
    *   This is a very common and secure way to provide configuration, especially for sensitive data like API keys.
    *   **Analogy:** When you hire a chef (your application), you give them a list of instructions for the day (environment variables) like "Today, use the fancy olive oil" or "The oven temperature should be 350 degrees."

4.  **`.env` File (Developer's Cheat Sheet):**
    *   For development, it can be tedious to set many environment variables manually every time you start the app.
    *   A `.env` file (pronounced "dot-env") is a simple text file where you can list these variables and their values.
    *   A library (like `dotenv` in our project) reads this file at startup and makes these values available as if they were real environment variables.
    *   **Important:** If your `.env` file contains secrets (like API keys), it should *never* be committed to version control (like Git). It's for your local setup only.
    *   **Analogy:** The `.env` file is like a personal sticky note on your desk with your preferred settings for a project. You don't share your personal sticky notes with the whole team.

5.  **Adaptability (One App, Many Environments):**
    *   By using external configuration, the *same application code* can behave differently in different environments (development, testing, staging, production) just by changing the environment variables.
    *   **Analogy:** The same car model can be driven gently in the city or pushed hard on a racetrack, depending on the driver and road conditions (the environment).

## How It Works: Accessing Settings in Our App

Let's see how different parts of our `html-to-pdf-service` use the configuration. They all import a central `config` object.

**Example 1: Setting the Server Port in `server.js`**
```javascript
// --- File: server.js (snippet) ---
const config = require('./src/config/config'); // 1. Import config
const logger = require('./src/utils/logger');
// ...
app.listen(config.port, () => { // 2. Use config.port
  logger.info(`Server running on port ${config.port}`);
});
```
1.  `const config = require('./src/config/config');`: We import the configuration object.
2.  `app.listen(config.port, ...)`: Instead of `app.listen(3000, ...)`, we use `config.port`. This `port` value is defined externally.

**Example 2: Redis Settings in `src/services/cacheService.js`**
(As seen in [Chapter 5: Caching Service](05_caching_service_.md))
```javascript
// --- File: src/services/cacheService.js (snippet) ---
const Redis = require('ioredis');
const config = require('../config/config'); // 1. Import config
// ...
class CacheService {
  constructor() {
    // 2. Use config.redis.url
    this.redisClient = new Redis(config.redis.url, { /* ... */ });
  }
  async set(key, value, expirySeconds = config.redis.ttl) { // 3. Use config.redis.ttl
    // ...
  }
}
```
1.  The `CacheService` imports the same `config` object.
2.  It uses `config.redis.url` to know which Redis server to connect to.
3.  It uses `config.redis.ttl` as the default expiry time for cached items.

**Example 3: Google Cloud Storage Settings in `src/services/storageService.js`**
(As seen in [Chapter 4: Cloud Storage Service](04_cloud_storage_service_.md))
```javascript
// --- File: src/services/storageService.js (snippet) ---
const { Storage } = require('@google-cloud/storage');
const config = require('../config/config'); // 1. Import config
// ...
class StorageService {
  constructor() {
    this.storage = new Storage({
      projectId: config.gcs.projectId, // 2. Use GCS settings
      keyFilename: config.gcs.keyFilename
    });
    this.bucket = this.storage.bucket(config.gcs.bucketName);
  }
}
```
1.  The `StorageService` also imports the `config` object.
2.  It uses `config.gcs.projectId`, `config.gcs.keyFilename`, and `config.gcs.bucketName` to configure its connection to Google Cloud Storage.

All these services get their specific settings from one central `config` object. If we need to change the Redis URL or the GCS bucket, we don't touch these service files; we change the configuration externally.

## Under the Hood: Loading the Configuration

How does this `config` object get its values? This magic happens in `src/config/config.js`, often with the help of a library called `dotenv`.

**The Process:**

1.  When the application starts, `src/config/config.js` is one of the first files loaded.
2.  The `dotenv` library is instructed to look for a file named `.env` in the project's root directory.
3.  If `.env` exists, `dotenv` reads all the `KEY=VALUE` pairs from it.
4.  For each pair, it sets an environment variable within the running application's process (e.g., `process.env.PORT = "3000"`).
5.  Then, `src/config/config.js` explicitly reads values from `process.env` (e.g., `process.env.PORT`, `process.env.REDIS_URL`).
6.  If an environment variable isn't set, `config.js` often provides a sensible default value (e.g., if `process.env.PORT` is not found, use `3000`).
7.  Finally, `config.js` exports an object containing all these settings, which other parts of the app can then import and use.

Let's visualize this:

```mermaid
sequenceDiagram
    participant App as Application Startup
    participant DotEnvLib as dotenv Library
    participant DotEnvFile as .env File
    participant ProcessEnv as process.env
    participant ConfigJS as src/config/config.js
    participant OtherServices as Other Services (e.g., server.js)

    App->>ConfigJS: Loads config.js
    ConfigJS->>DotEnvLib: require('dotenv').config()
    DotEnvLib->>DotEnvFile: Reads KEY=VALUE pairs
    DotEnvFile-->>DotEnvLib: Returns pairs
    DotEnvLib->>ProcessEnv: Sets process.env.KEY = VALUE
    ConfigJS->>ProcessEnv: Reads process.env.PORT, process.env.REDIS_URL etc.
    ProcessEnv-->>ConfigJS: Returns values (or undefined)
    Note over ConfigJS: Applies default values if needed
    ConfigJS-->>App: Exports config object
    App->>OtherServices: Other services load
    OtherServices->>ConfigJS: require('./src/config/config') (gets cached object)
    ConfigJS-->>OtherServices: Provides config object
```

**A. The `.env` File (Example):**
This file lives in the root of your project but *should not be committed to Git if it contains secrets*.

```
# .env (Example for local development)
PORT=3001
NODE_ENV=development

GCS_PROJECT_ID=my-gcp-project-id
GCS_BUCKET_NAME=my-dev-pdf-bucket
GCS_KEYFILE=./path/to/your-dev-keyfile.json

REDIS_URL=redis://localhost:6379
REDIS_TTL=600 # 10 minutes for dev
```
*   Lines starting with `#` are comments.
*   Each line defines a variable and its value.

**B. The `src/config/config.js` File:**
This file reads the environment variables (populated by `dotenv` or set directly in the deployment environment) and exports the configuration object.

```javascript
// --- File: src/config/config.js (simplified) ---
require('dotenv').config(); // 1. Load .env file into process.env

module.exports = {
  // 2. Read from process.env, provide defaults
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',

  gcs: {
    projectId: process.env.GCS_PROJECT_ID,
    bucketName: process.env.GCS_BUCKET_NAME,
    keyFilename: process.env.GCS_KEYFILE
  },
  redis: {
    url: process.env.REDIS_URL || 'redis://localhost:6379',
    ttl: parseInt(process.env.REDIS_TTL) || 300 // Default 5 mins
  }
  // ... other configurations
};
```
1.  `require('dotenv').config();`: This line tells the `dotenv` library to do its job: find `.env`, read it, and load its contents into `process.env`.
2.  `process.env.VARIABLE_NAME || defaultValue`: For each setting, we try to read it from `process.env`.
    *   If `process.env.PORT` is set (either from `.env` or directly in the environment), we use that value.
    *   If it's *not* set, we use the `|| defaultValue` (e.g., `3000` for `port`).
    *   `parseInt(process.env.REDIS_TTL)`: Environment variables are always strings, so if we need a number (like for `ttl`), we must convert it using `parseInt()`.

**How this works for different environments:**
*   **Development:** You use a `.env` file with your local settings (e.g., `PORT=3001`, local Redis URL).
*   **Production:** You *don't* deploy the `.env` file. Instead, you set the environment variables directly on your production server or cloud platform (e.g., `PORT=8080`, production Redis URL, production GCS credentials). The `config.js` file will pick up these production environment variables.

This system provides a clean separation between the application's code and its environment-specific settings.

## Conclusion

You've now learned about **Configuration Management**, the crucial "control panel" for our `html-to-pdf-service`. Key takeaways:
*   It centralizes application settings like port numbers, service URLs, and API keys.
*   It allows settings to be managed externally (via environment variables or a `.env` file for development) without changing the codebase.
*   This makes the application adaptable to different environments (development, production) and improves security by keeping secrets out of the code.
*   Our project uses `dotenv` to load `.env` files for development and `src/config/config.js` to read from `process.env` and provide defaults.

Proper configuration management is essential for building robust, maintainable, and secure applications. It ensures that your application can be easily deployed and run in various setups.

Now that we know how our application is configured, how do we keep an eye on it while it's running? How do we know if it's healthy or if errors are occurring? That's what we'll explore in the next chapter: [Chapter 7: Observability (Logging & Health Checks)](07_observability__logging___health_checks__.md).

---

Generated By NOVA