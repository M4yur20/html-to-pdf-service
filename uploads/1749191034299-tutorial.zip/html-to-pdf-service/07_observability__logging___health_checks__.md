# Chapter 7: Observability (Logging & Health Checks)

Welcome to the final chapter of our core tutorial! In [Chapter 6: Configuration Management](06_configuration_management_.md), we learned how our `html-to-pdf-service` manages its settings for different environments. Now that our service is configured and (hopefully!) running smoothly, how do we keep an eye on it? How do we know if it's healthy, or what happened if something unexpectedly goes wrong? That's where **Observability** comes in!

## What's the Big Deal? Knowing How Your App is Doing

Imagine our `html-to-pdf-service` is live, and many users are happily converting their HTML documents to PDFs.
*   But what if, suddenly, some users start reporting that they're getting errors? What went wrong? Where in the code did the problem occur?
*   Is the service even running correctly? Are all its important parts, like the [Caching Service](05_caching_service_.md) that speeds things up, working as expected?
*   How is the service performing overall? Is it handling requests quickly, or is it getting bogged down?

Observability is all about making our application "observable" – giving it ways to tell us how it's doing, what it's doing, and if it needs help. It's like giving our application a voice and a set of vital sign monitors. This chapter will explore three key aspects: Logging, Health Checks, and a brief look at Metrics.

## Key Concepts: The Application's Diary, Pulse, and Dashboard

Let's break down the main ideas:

1.  **Logging (The Application's Diary):**
    *   This is like a detailed diary or "flight recorder" for our application.
    *   It captures important events, informational messages, and especially errors, writing them down to files or showing them on the console.
    *   **Why it's useful:**
        *   **Debugging:** If something goes wrong, logs are often the first place developers look to understand the sequence of events and find the source of the bug.
        *   **Auditing:** Sometimes, you need to track what happened, like which user initiated a specific action (though our current service doesn't have user-specific auditing).
    *   **Analogy:** Imagine your application writes in a journal. "A new request came in at 10:05 AM." "Successfully generated PDF for request X." "Oh no! An error occurred at 10:06 AM while trying to save to cloud storage!"

2.  **Health Check Endpoints (The Application's Pulse):**
    *   These are special web addresses (URLs) in our application, like `/api/health`, that provide a quick way to check if the service is alive and functioning correctly.
    *   Think of it like a doctor checking your pulse and temperature – a quick vital sign check.
    *   **Why it's useful:**
        *   **Monitoring:** Automated systems can regularly "ping" this endpoint to ensure the service is up. If it doesn't respond correctly, alerts can be sent.
        *   **Dependency Checks:** The health check can also verify if its critical dependencies (like the [Caching Service](05_caching_service_.md)'s Redis database) are also healthy.
    *   **Analogy:** It's like an "Are you okay?" button for the service. You "press" it (by visiting the URL), and it replies "Yes, I'm fine, and my cache is working too!" or "Help, I can't connect to my cache!"

3.  **Metrics (The Application's Performance Dashboard - via Prometheus):**
    *   Metrics are numerical measurements that give us deeper insights into the application's performance and behavior over time.
    *   Examples: How many requests is the service handling per second? How long does it take to process a typical request? How much memory is it using?
    *   Our service uses a tool that exposes these metrics in a format understood by **Prometheus**, a popular system for collecting and visualizing such data.
    *   **Analogy:** Think of the dashboard in your car showing your speed, engine RPM, and fuel level. Metrics provide similar insights for our application.

## How It Works: Seeing Observability in Action

Let's see how these concepts are used in our `html-to-pdf-service`.

### 1. Logging: Reading the Application's Diary

Our application uses a logging utility (from `src/utils/logger.js`, which we'll look at later) to write messages.

**Example: Logging an informational message**
When the server starts, it logs a message:
```javascript
// --- File: server.js (snippet) ---
const logger = require('./src/utils/logger');
const config = require('./src/config/config');
// ...
app.listen(config.port, () => {
  logger.info(`Server running on port ${config.port}`); // Log server start
});
```
*   `logger.info(...)`: This writes an "informational" level message.
*   **Output (in console/log file):** `2023-10-27T10:00:00.123Z info: Server running on port 3000`

**Example: Logging an error**
Our [central error handler](01_application_server___middleware_pipeline_.md) (from `src/middleware/errorHandler.js`) logs errors:
```javascript
// --- File: src/middleware/errorHandler.js (snippet) ---
const logger = require('../utils/logger');
// ...
module.exports = (err, req, res, next) => {
  logger.error('Error:', { // Log an "error" level message
    message: err.message,
    // ... other details
  });
  // ... send error response to client
};
```
*   `logger.error(...)`: This writes an "error" level message, which is more critical.
*   **Output (in console/log file):** `2023-10-27T10:05:30.456Z error: Error: Something went wrong during PDF generation` (plus more details like a stack trace).

These logs are invaluable for developers to trace what the application was doing, especially when troubleshooting.

### 2. Health Checks: Taking the Application's Pulse

Our service provides a health check endpoint at `/api/health`.

**Setting it up (in `server.js`):**
```javascript
// --- File: server.js (snippet) ---
const healthRoutes = require('./src/routes/healthRoutes');
// ...
app.use('/api/health', healthRoutes); // Route requests for /api/health
```
This line tells our Express server that any request starting with `/api/health` should be handled by the rules defined in `src/routes/healthRoutes.js`.

**What you get when you visit `/api/health`:**
If you open `http://localhost:YOUR_PORT/api/health` in your browser (or use a tool like `curl`), you'll get a JSON response.
*   **Input:** A `GET` request to `/api/health`.
*   **Output (Example):**
    ```json
    {
      "status": "ok",
      "timestamp": "2023-10-27T10:15:00.789Z",
      "uptime": 1234.56,
      "cache": {
        "status": "up",
        "message": "Redis connection is healthy"
      }
    }
    ```
This tells us:
*   `status: "ok"`: The application itself is running.
*   `uptime`: How long the service has been running in seconds.
*   `cache.status: "up"`: The [Caching Service](05_caching_service_.md) (Redis) is also healthy. If Redis were down, this status might be "down".

There's also a `/api/health/detailed` endpoint for more information, like memory usage.

### 3. Prometheus Metrics: Checking the Performance Dashboard

Our service exposes detailed performance metrics at `/metrics`.

**Setting it up (in `server.js`):**
```javascript
// --- File: server.js (snippet) ---
const prometheusMiddleware = require('express-prometheus-middleware');
// ...
app.use(prometheusMiddleware({
  metricsPath: '/metrics',      // Where to access metrics
  collectDefaultMetrics: true // Collect standard Node.js metrics
}));
```
The `express-prometheus-middleware` automatically gathers various metrics.

**What you get when you visit `/metrics`:**
If you open `http://localhost:YOUR_PORT/metrics`, you'll see a lot of text. This isn't meant to be human-readable directly but is for a Prometheus server to collect.
*   **Input:** A `GET` request to `/metrics`.
*   **Output (Snippet):**
    ```
    # HELP http_requests_total Total number of HTTP requests made.
    # TYPE http_requests_total counter
    http_requests_total{method="POST",route="/api/pdf/convert",code="200"} 57
    # HELP nodejs_active_handles_total Number of active libuv handles.
    # TYPE nodejs_active_handles_total gauge
    nodejs_active_handles_total 5
    # HELP http_request_duration_seconds HTTP request duration in seconds.
    # TYPE http_request_duration_seconds histogram
    http_request_duration_seconds_bucket{le="0.1",method="POST",route="/api/pdf/convert",code="200"} 12
    http_request_duration_seconds_bucket{le="0.5",method="POST",route="/api/pdf/convert",code="200"} 45
    ...
    ```
This data includes counts of requests, how long they took, memory usage, etc. This is the raw data for your performance dashboard.

## Under the Hood: How Observability is Implemented

Let's peek at the internal workings.

### 1. The Logger: `src/utils/logger.js` (using Winston)

Our application's logging capabilities are provided by a library called **Winston**. The `src/utils/logger.js` file configures it.

**Simplified `src/utils/logger.js`:**
```javascript
// --- File: src/utils/logger.js (simplified) ---
const winston = require('winston');

const logger = winston.createLogger({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug', // 1
  format: winston.format.combine( // 2
    winston.format.timestamp(),
    winston.format.printf(info => `${info.timestamp} ${info.level}: ${info.message}`)
  ),
  transports: [ // 3
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});

if (process.env.NODE_ENV !== 'production') { // 4
  // Add colorized console output for development
}
module.exports = logger;
```
1.  **`level`**: Determines the minimum severity of messages to log. In production, it's `info`; in development, it's `debug` (more verbose).
2.  **`format`**: Defines how each log message should look. Here, it includes a timestamp, the log level (info, error), and the message. The actual project also includes stack traces for errors.
3.  **`transports`**: Specifies where the log messages should be sent.
    *   `winston.transports.Console()`: Sends logs to the terminal/console.
    *   `winston.transports.File(...)`: Sends logs to files. We have one for errors (`error.log`) and one for all logs (`combined.log`).
4.  In development, we often add color to console logs for easier reading.

### 2. The Health Check Route: `src/routes/healthRoutes.js`

This file handles requests to the `/api/health` endpoint.

**Simplified `src/routes/healthRoutes.js`:**
```javascript
// --- File: src/routes/healthRoutes.js (simplified) ---
const express = require('express');
const router = express.Router();
const cacheService = require('../services/cacheService'); // For Redis health

router.get('/', async (req, res) => { // Handles GET /api/health
  const cacheHealth = await cacheService.getHealth(); // 1. Check cache

  res.json({ // 2. Send JSON response
    status: 'ok',
    uptime: process.uptime(), // How long app has been running
    cache: cacheHealth
  });
});
module.exports = router;
```
1.  `await cacheService.getHealth()`: It calls a method on our `cacheService` (which talks to Redis, our [Caching Service](05_caching_service_.md)). The `getHealth` method in `cacheService` typically pings the Redis server to see if it's responsive.
2.  `res.json(...)`: It constructs and sends the JSON response with the overall status, uptime, and the cache's health status.

Let's visualize the health check flow:
```mermaid
sequenceDiagram
    participant Client
    participant Server as App Server (Express.js)
    participant HealthRoute as /api/health Handler
    participant CacheSvc as CacheService (Redis)

    Client->>Server: GET /api/health
    Server->>HealthRoute: Request forwarded
    HealthRoute->>CacheSvc: getHealth()
    CacheSvc->>CacheSvc: Ping Redis server
    CacheSvc-->>HealthRoute: Cache status (e.g., {status: 'up', ...})
    HealthRoute->>Server: Prepare JSON response with uptime & cache status
    Server-->>Client: Sends JSON Response
```

### 3. Prometheus Metrics Middleware: `express-prometheus-middleware`

The `express-prometheus-middleware` we added in `server.js` is a third-party library that does most of the heavy lifting for metrics.
*   When a request comes in, it automatically records its path, method, and status code.
*   It measures how long the request takes to process.
*   It collects default Node.js metrics like memory usage and CPU utilization.
*   It then makes all this data available at the `/metrics` path in the specific text format that Prometheus expects.

For basic metrics, it's largely a "plug-and-play" solution. For more advanced, custom application metrics, you would typically use a Prometheus client library directly to define and increment your own counters, gauges, and histograms.

## Conclusion

You've now learned about **Observability** in our `html-to-pdf-service`, focusing on:
*   **Logging:** How our application keeps a detailed diary of events and errors using Winston, helping with debugging.
*   **Health Checks:** How the `/api/health` endpoint acts as a vital sign monitor, quickly telling us if the service and its dependencies (like the cache) are operational.
*   **Metrics:** How Prometheus metrics (via `express-prometheus-middleware`) provide a dashboard's worth of data for deeper performance insights.

These tools are essential for operating any application in a production environment. They help you understand what your application is doing, diagnose problems when they arise, and ensure it's running smoothly for your users.

This chapter marks the end of our tour through the core components of the `html-to-pdf-service` project. We hope this journey from the [Application Server & Middleware Pipeline](01_application_server___middleware_pipeline_.md) all the way to Observability has given you a solid understanding of how a modern web service can be structured! Keep exploring, keep building, and keep learning!

---

Generated By NOVA