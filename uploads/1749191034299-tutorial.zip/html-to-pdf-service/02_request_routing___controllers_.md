# Chapter 2: Request Routing & Controllers

Welcome back! In [Chapter 1: Application Server & Middleware Pipeline](01_application_server___middleware_pipeline_.md), we learned how our `html-to-pdf-service` sets up an "assembly line" (the middleware pipeline) to prepare incoming requests. Now, imagine a request has successfully passed all those initial checks. How does the application know *what to do* with it? If one request is to convert HTML to PDF, and another is to check the service's health, how does it go to the right place?

That's where **Request Routing & Controllers** come in!

## What's the Big Deal? Directing Traffic

Imagine you send a letter to a large company. The mailroom (our Application Server from Chapter 1) receives it. The security desk (middleware) checks it for anything suspicious. But then, how does the letter get to the correct department and person?

*   If the letter is for the "Sales Department" about "Product A," it needs to go to a specific sales manager.
*   If it's for "Customer Support" about "a billing issue," it needs to go to a support agent.

Our web service faces a similar challenge. When a request arrives at a URL like `/api/pdf/convert` with some HTML data, it needs to be directed to the code that *actually handles PDF conversion*. A request to `/api/health` needs to go to code that checks the system's health.

**Request Routing** is like the company's directory or the mail sorter. It looks at the "address" on the request (the URL path, e.g., `/api/pdf/convert`) and the "type" of request (the HTTP method, e.g., `POST`, `GET`). Based on this, it decides which "department" or specific function should handle it.

This specific function is called a **Controller**. The controller is like the department manager or the specialist who takes the request, does the necessary work (like talking to other services or performing calculations), and then prepares a reply.

Without routing and controllers, our `server.js` file would become a giant, unmanageable mess trying to handle every possible request type in one place. This system keeps our code organized and understandable.

## Key Concepts: The Directory and The Doers

Let's break this down:

1.  **Routing (The Directory):**
    *   This is the mechanism that matches an incoming request's URL and HTTP method to a specific piece of code.
    *   Express.js (our application server framework) provides powerful tools for this, often using something called a `Router`.
    *   **Analogy:** Think of a receptionist at a doctor's office. You tell them you have an appointment with Dr. Smith for a check-up. The receptionist (Router) looks at their schedule (routing rules) and directs you to Dr. Smith's room.
    *   The URL path (e.g., `/api/pdf/convert`) and HTTP method (e.g., `POST`) are key pieces of information the router uses.

2.  **Controllers (The Doers):**
    *   These are JavaScript functions that are executed when a route is matched.
    *   They contain the actual logic to handle the request.
    *   A controller might:
        *   Read data from the request (e.g., the HTML to convert).
        *   Call other specialized services (like the [PDF Generation Service](03_pdf_generation_service_.md) or [Cloud Storage Service](04_cloud_storage_service_.md)).
        *   Prepare a response to send back to the client (e.g., a success message with a link to the PDF, or an error message).
    *   **Analogy:** Dr. Smith is the controller. Once you're in their room, they perform the check-up (process the request), maybe consult with a nurse (another service), and then give you a diagnosis or prescription (the response).

## How It Works: A Request Finds Its Way

Let's follow a request for PDF conversion:

1.  A client sends a `POST` request to `/api/pdf/convert` with HTML data.
2.  The Application Server (Express.js) receives it.
3.  The request goes through the [Middleware Pipeline](01_application_server___middleware_pipeline_.md) (security checks, data parsing, etc.).
4.  If all middleware pass, Express then looks at its **routing rules**.
5.  It finds a rule that says: "For `POST` requests to `/api/pdf/convert`, execute the `convertToPdf` function."
6.  The `convertToPdf` **controller** function is then called. This function will contain the logic to handle the PDF conversion.

### Setting Up the "Directory" (Routes)

In our `server.js`, we tell Express where to find the routing rules for different parts of our API:

```javascript
// --- File: server.js (simplified snippet) ---
const express = require('express');
const pdfRoutes = require('./src/routes/pdfRoutes'); // 1. Import route definitions
const healthRoutes = require('./src/routes/healthRoutes');
const app = express();

// ... (middleware like helmet, express.json are set up here - see Chapter 1)

// 2. Tell Express: if URL starts with /api/pdf, use pdfRoutes
app.use('/api/pdf', pdfRoutes);
// 3. If URL starts with /api/health, use healthRoutes
app.use('/api/health', healthRoutes);

// ... (error handler and app.listen)
```
1.  We `require` files that define specific sets of routes (e.g., `pdfRoutes` for all PDF-related actions).
2.  `app.use('/api/pdf', pdfRoutes);` tells Express: "Any request whose URL path starts with `/api/pdf` should be handled by the rules defined in `pdfRoutes`."
3.  Similarly for `/api/health`. This keeps our main `server.js` clean and delegates routing logic to specialized files.

Now, let's look inside one of these route files, `src/routes/pdfRoutes.js`:

```javascript
// --- File: src/routes/pdfRoutes.js (simplified) ---
const express = require('express');
const router = express.Router(); // 1. Create a router for PDF routes
const pdfController = require('../controllers/pdfController'); // 2. Import controller

// 3. Define a rule: POST to /convert -> call pdfController.convertToPdf
router.post('/convert', pdfController.convertToPdf);

module.exports = router; // 4. Export the router
```
1.  `express.Router()` creates a mini, self-contained "router" object. Think of it as a sub-directory for PDF-related routes.
2.  We import `pdfController`, which contains the actual functions to handle requests.
3.  `router.post('/convert', pdfController.convertToPdf);` is the core rule:
    *   `router.post`: This rule applies only to `POST` HTTP requests.
    *   `'/convert'`: This is the path *relative* to the path defined in `server.js`. Since `server.js` used `/api/pdf` for `pdfRoutes`, this rule matches the full path `/api/pdf/convert`.
    *   `pdfController.convertToPdf`: This is the controller function that will be executed if the method and path match.

We can also add route-specific middleware here. Remember `validateConvertRequest` and `cacheMiddleware` from Chapter 1? They are perfect for this specific route:

```javascript
// --- File: src/routes/pdfRoutes.js (with route-specific middleware) ---
const express = require('express');
const router = express.Router();
const { validateConvertRequest } = require('../middleware/validation');
const { cacheMiddleware } = require('../middleware/cache');
const auth = require('../middleware/auth'); // Authentication middleware
const pdfController = require('../controllers/pdfController');

router.post('/convert',
  validateConvertRequest, // 1. Validate input specific to /convert
  cacheMiddleware,      // 2. Check if response is already cached
  auth,                 // 3. Check if user is authorized
  pdfController.convertToPdf // 4. If all good, call the controller
);
module.exports = router;
```
These middleware will *only* run for the `/api/pdf/convert` route, in the order they are listed, before the `pdfController.convertToPdf` function is called.

### The "Doer" (Controller) Logic

Now let's peek into a simplified version of what `pdfController.convertToPdf` in `src/controllers/pdfController.js` might do:

```javascript
// --- File: src/controllers/pdfController.js (simplified) ---
// We'll learn about these services in later chapters!
// const pdfService = require('../services/pdfService');
// const storageService = require('../services/storageService');
const logger = require('../utils/logger');

exports.convertToPdf = async (req, res, next) => {
  try {
    // 1. Get data from the request (e.g., HTML content)
    // req.body was populated by the express.json() middleware from Chapter 1
    const { input, format } = req.body;
    logger.info(`Received request to convert to PDF, format: ${format}`);

    // 2. Call other services to do the actual work (simplified here)
    // const pdfBuffer = await pdfService.generatePdf(input, { format });
    // const fileInfo = await storageService.uploadFile(pdfBuffer);
    const fakePdfUrl = `http://example.com/generated_document.pdf`;
    logger.info(`Pretending to generate PDF: ${input.substring(0,50)}...`);


    // 3. Send a response back to the client
    res.json({
      success: true,
      url: fakePdfUrl, // In a real app, this would be the actual URL
      metadata: { format }
    });
  } catch (error) {
    logger.error('Error in PDF conversion controller:', error);
    // 4. If something goes wrong, pass error to the central error handler
    next(error);
  }
};
```
Let's break down this controller function:
*   `async (req, res, next) => { ... }`:
    *   `req` (Request): An object containing information about the incoming HTTP request (e.g., `req.body` for POST data, `req.query` for URL parameters, `req.headers`).
    *   `res` (Response): An object used to send back the HTTP response to the client (e.g., `res.json()` to send JSON, `res.send()` to send text, `res.status()` to set status code).
    *   `next`: A function used to pass control to the next middleware. If an error occurs, we call `next(error)` to pass it to our [central error handler](01_application_server___middleware_pipeline_.md).

*   **Inside the `try` block:**
    1.  **Get data from request:** `const { input, format } = req.body;` extracts the HTML content (`input`) and desired PDF `format` from the request body. The `express.json()` middleware we saw in Chapter 1 already parsed the JSON request body into `req.body`.
    2.  **Call other services:** This is where the controller orchestrates the main work.
        *   It *would* call `pdfService.generatePdf(...)` (from [Chapter 3: PDF Generation Service](03_pdf_generation_service_.md)) to do the actual conversion.
        *   Then, it *would* call `storageService.uploadFile(...)` (from [Chapter 4: Cloud Storage Service](04_cloud_storage_service_.md)) to save the PDF and get a URL.
        *   For simplicity here, we're just logging and creating a `fakePdfUrl`.
    3.  **Send response:** `res.json({ ... });` sends a JSON response back to the client indicating success and providing the URL to the generated PDF.

*   **Inside the `catch` block:**
    4.  **Error handling:** If any error occurs during the `try` block (e.g., PDF generation fails), the `catch` block catches it. `next(error)` passes the error to Express's error handling middleware (which we set up in `server.js` in Chapter 1), ensuring a consistent error response is sent to the client.

## Under the Hood: A Request's Full Journey to the Controller

Let's visualize the path of a `POST` request to `/api/pdf/convert`:

```mermaid
sequenceDiagram
    participant Client
    participant AppServer as Application Server (Express.js)
    participant MiddlewarePipeline as General Middleware (Ch1)
    participant APIRouter as /api/pdf Router (in pdfRoutes.js)
    participant ConvertRouteMiddleware as Route-Specific Middleware
    participant PDFController as pdfController.convertToPdf

    Client->>AppServer: POST /api/pdf/convert with HTML data
    AppServer->>MiddlewarePipeline: Request enters general middleware (JSON parsing, security, etc.)
    MiddlewarePipeline->>AppServer: General middleware processing complete
    AppServer->>APIRouter: Matched '/api/pdf', passes to pdfRoutes.js router
    APIRouter->>ConvertRouteMiddleware: Matched 'POST /convert', passes to route's middleware (validation, cache)
    ConvertRouteMiddleware->>APIRouter: Route-specific middleware complete
    APIRouter->>PDFController: Calls pdfController.convertToPdf function
    PDFController->>PDFController: Executes conversion logic (calls other services)
    PDFController->>AppServer: Prepares JSON response (e.g., {url: "..."})
    AppServer->>Client: Sends HTTP Response back to Client
```

1.  **Client to Server:** The client sends the request.
2.  **General Middleware:** The request first goes through the global middleware defined in `server.js` using `app.use()` (like `helmet`, `express.json`, `cors`, `rateLimit`).
3.  **Main Router (in `server.js`):** Express sees `app.use('/api/pdf', pdfRoutes);`. Since the URL `/api/pdf/convert` starts with `/api/pdf`, it hands the request (and the remaining part of the path, which is `/convert`) to the `pdfRoutes` router.
4.  **Specific Router (in `src/routes/pdfRoutes.js`):**
    *   The `pdfRoutes` router looks at its rules. It finds `router.post('/convert', validateConvertRequest, cacheMiddleware, auth, pdfController.convertToPdf);`.
    *   It matches the HTTP method `POST` and the remaining path `/convert`.
5.  **Route-Specific Middleware:** The request now goes through `validateConvertRequest`, then `cacheMiddleware`, then `auth` (if these call `next()`).
6.  **Controller Execution:** If all route-specific middleware pass, `pdfController.convertToPdf(req, res, next)` is finally called.
7.  **Controller Logic:** The controller function does its job (validates input, calls services like [PDF Generation Service](03_pdf_generation_service_.md) and [Cloud Storage Service](04_cloud_storage_service_.md)).
8.  **Response:** The controller uses `res.json()` (or similar) to send a response back to the client.

This layered approach ensures that logic is well-organized and that requests are processed systematically.

## Conclusion

You've now seen how our `html-to-pdf-service` uses **Request Routing and Controllers** to manage incoming requests after they've passed through the initial middleware pipeline.
*   **Routing** acts like a sophisticated address book, using the URL and HTTP method to find the right destination for a request.
*   **Controllers** are the specific functions at those destinations that perform the actual work, orchestrate calls to other services, and prepare the final response.

This organization is crucial for building maintainable and scalable web applications. It keeps different concerns separated: `server.js` for overall setup, `routes/*.js` files for defining API endpoints, and `controllers/*.js` files for housing the business logic for those endpoints.

Now that we know how a request reaches the `pdfController.convertToPdf` function, what happens inside that function to actually create a PDF? That's exactly what we'll explore in the next chapter: [Chapter 3: PDF Generation Service](03_pdf_generation_service_.md)!

---

Generated By NOVA