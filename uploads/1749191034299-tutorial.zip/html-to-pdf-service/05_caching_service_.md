# Chapter 5: Caching Service

Welcome back! In [Chapter 4: Cloud Storage Service](04_cloud_storage_service_.md), we learned how our `html-to-pdf-service` securely stores the generated PDF files in Google Cloud Storage and provides a temporary link for users to download them. This is great for making sure PDFs are accessible. But what if many users request the *exact same* PDF? For example, if a popular news article's URL is converted to PDF multiple times. Generating the PDF and uploading it to cloud storage every single time would be repetitive and slow.

This is where our **Caching Service** comes in to make things much faster!

## What's the Big Deal? Speeding Things Up with a "Quick Memory"

Imagine you're a librarian (our service).
*   The first time someone asks for a specific, newly published book (a PDF from new HTML input), you have to go through the whole process: find the manuscript (HTML), send it to the printing press ([PDF Generation Service](03_pdf_generation_service_.md)), get the printed book (PDF buffer), and then carefully store it on a specific shelf in the main library ([Cloud Storage Service](04_cloud_storage_service_.md)), finally giving the user a checkout slip (the signed URL). This takes time.

*   Now, what if a second person asks for the *exact same book* just a few minutes later? Going through the entire process again would be inefficient.

The **Caching Service** is like having a small shelf of "recently popular books" right at your librarian's desk. If a request comes for a PDF that was generated very recently (based on identical input parameters), the service can grab the result (like the link to the already stored PDF) from this quick-access shelf instead of doing all the work again. This makes the response much, much faster!

Our Caching Service uses **Redis**, which is like a super-fast, short-term memory for our application.

## Key Concepts: The Speedy Shelf

Let's break down the main ideas:

1.  **Caching (The Speedy Shelf):**
    *   This is the general idea of storing the results of expensive operations (like generating a PDF and getting its cloud URL) temporarily.
    *   If the same request comes again soon, we can serve the stored result directly, saving time and resources.
    *   **Analogy:** The librarian's small shelf of recently requested books.

2.  **Redis (The High-Tech Shelf):**
    *   Redis is an in-memory data store. "In-memory" means it keeps data in the server's RAM, which is very fast to access. It's perfect for caching.
    *   **Analogy:** Think of Redis as a super-organized, lightning-fast digital shelf.

3.  **Cache Key (The Book's Title and Edition):**
    *   To find something in the cache, we need a unique identifier for each request. This is called a "cache key."
    *   For our PDF service, the cache key is typically created from the input parameters of the request (e.g., the HTML content or URL, and any PDF generation options). If all these are identical to a previous request, the cache key will be the same.
    *   **Analogy:** The cache key is like the exact title and edition of the book. "Hamlet, Third Edition" is different from "Hamlet, Fourth Edition."

4.  **Cache Hit (Found it on the Shelf!):**
    *   When a request comes in, the service first checks the cache using the cache key. If the result is found in the cache, it's a "cache hit."
    *   The service can then immediately return the cached result.
    *   **Analogy:** The librarian quickly finds the book on the speedy shelf.

5.  **Cache Miss (Not on the Shelf... Yet):**
    *   If the result is *not* found in the cache (it's a new request, or the cached item expired), it's a "cache miss."
    *   The service then has to do the full work: generate the PDF, store it, etc.
    *   *Crucially*, after getting the result, the service will store this new result in the cache (with its key) so that future identical requests can be a cache hit.
    *   **Analogy:** The librarian doesn't find the book on the speedy shelf, goes to the main library, gets it, and *then puts a copy on the speedy shelf* before giving it to the user.

6.  **Cache Expiry / TTL (Time To Live - How Long it Stays on the Shelf):**
    *   We don't want cached items to stay in Redis forever. The information might become outdated, or Redis might run out of memory.
    *   So, when we store something in the cache, we usually set an "expiry time" or "Time To Live" (TTL). After this time, the item is automatically removed from the cache.
    *   **Analogy:** The librarian only keeps books on the speedy shelf for, say, one hour. After that, they are removed to make space for newer popular books.

## How It Works: The Request's Journey with Caching

Let's trace a request to `/api/pdf/convert` when caching is involved:

1.  A user sends a `POST` request to `/api/pdf/convert` with HTML data and options.
2.  The request goes through initial middleware (security, etc. from [Chapter 1: Application Server & Middleware Pipeline](01_application_server___middleware_pipeline_.md)).
3.  It then hits our special `cacheMiddleware`.
4.  **Inside `cacheMiddleware`:**
    *   It creates a unique `cacheKey` based on the request's body (the HTML and options).
    *   It asks the `CacheService` (which talks to Redis): "Do you have data for this `cacheKey`?"
    *   **If YES (Cache Hit):**
        *   Redis returns the stored data (e.g., the JSON response containing the PDF URL).
        *   The `cacheMiddleware` immediately sends this cached data back to the user. The request is done! Super fast!
    *   **If NO (Cache Miss):**
        *   The `cacheMiddleware` lets the request continue to the `pdfController` (from [Chapter 2: Request Routing & Controllers](02_request_routing___controllers_.md)).
        *   The `pdfController` does its work:
            *   Calls the [PDF Generation Service](03_pdf_generation_service_.md) to create the PDF.
            *   Calls the [Cloud Storage Service](04_cloud_storage_service_.md) to upload the PDF and get a signed URL.
            *   Prepares the JSON response.
        *   Just before sending the response to the user, the `cacheMiddleware` (which cleverly intercepted the response) tells the `CacheService`: "Store this JSON response in Redis using that `cacheKey` we made earlier, and set an expiry time."
        *   The JSON response is sent to the user.

The next time an identical request comes in (before the cache entry expires), it will be a cache hit!

### Using the Cache: The `cacheMiddleware`

In our `html-to-pdf-service`, caching is primarily handled by a middleware function. You might remember from [Chapter 2: Request Routing & Controllers](02_request_routing___controllers_.md) that we can add middleware specifically to certain routes.

Here's how `cacheMiddleware` is added in `src/routes/pdfRoutes.js`:
```javascript
// --- File: src/routes/pdfRoutes.js (snippet) ---
// ... other imports
const { cacheMiddleware } = require('../middleware/cache'); // 1. Import
const pdfController = require('../controllers/pdfController');

router.post('/convert',
  // ... other middleware like validation ...
  cacheMiddleware,      // 2. Add cacheMiddleware to the chain
  pdfController.convertToPdf
);
// ...
```
1.  We import `cacheMiddleware` from `src/middleware/cache.js`.
2.  It's placed in the middleware chain *before* the `pdfController.convertToPdf`. This allows it to check the cache first.

Now, a simplified look at `src/middleware/cache.js`:
```javascript
// --- File: src/middleware/cache.js (simplified) ---
const cacheService = require('../services/cacheService'); // Our Redis helper
const logger = require('../utils/logger');

exports.cacheMiddleware = async (req, res, next) => {
  // 1. Create a unique key from the request body
  const cacheKey = `pdf-${JSON.stringify(req.body)}`;

  try {
    // 2. Try to get data from cache
    const cachedResult = await cacheService.get(cacheKey);
    if (cachedResult) {
      logger.info(`Cache HIT for key: ${cacheKey}`);
      return res.json(cachedResult); // 3. Serve from cache
    }

    logger.info(`Cache MISS for key: ${cacheKey}`);
    // 4. If miss, hook into the response to cache it later
    const originalJson = res.json;
    res.json = function(data) { // Intercept res.json
      if (res.statusCode === 200 && data.success === true) {
        // 5. Cache successful responses
        cacheService.set(cacheKey, data)
          .catch(err => logger.error('Cache set error:', err));
      }
      res.json = originalJson; // Restore original res.json
      return res.json(data);   // Send response
    };

    next(); // 6. Continue to controller if miss
  } catch (error) {
    logger.error('Cache middleware error:', error);
    next(); // Continue on error, don't break request
  }
};
```
1.  **`const cacheKey = ...`**: It creates a unique string key. `JSON.stringify(req.body)` turns the request's input data (HTML, options) into a consistent string. We prefix it with `pdf-` for clarity.
2.  **`await cacheService.get(cacheKey)`**: It calls our `cacheService` (which we'll look at next) to check Redis for this key.
3.  **`if (cachedResult) { ... }`**: If `cachedResult` is not null (cache hit!), it sends the cached JSON response and the request ends here.
4.  **`const originalJson = res.json; res.json = function(data) { ... }`**: This is a clever bit! If it's a cache miss, we want to cache the response *after* the controller generates it. This code temporarily replaces Express's `res.json` function with our own.
5.  **`cacheService.set(cacheKey, data)`**: Inside our custom `res.json`, if the response from the controller is successful (`statusCode === 200` and `data.success === true`), we tell `cacheService` to store this `data` in Redis with the `cacheKey`. The actual project gets the TTL (expiry time) from [Configuration Management](06_configuration_management_.md).
6.  **`next()`**: If it was a cache miss, `next()` passes control to the next middleware or, in this case, the `pdfController`.

**Input (to `cacheMiddleware`):** An HTTP request (`req`).
**Output:**
*   If Cache Hit: The cached HTTP response is sent directly.
*   If Cache Miss: The request proceeds, and the eventual successful response from the controller is stored in the cache for next time.

## Under the Hood: Talking to Redis with `CacheService`

The `cacheMiddleware` uses another service, `CacheService` (from `src/services/cacheService.js`), to do the actual talking with Redis.

Let's visualize the interaction for a cache check:

```mermaid
sequenceDiagram
    participant CM as cacheMiddleware
    participant CS as CacheService
    participant RDB as Redis Database

    CM->>CS: get("pdf-{...request_body...}")
    CS->>RDB: GET "pdf-{...request_body...}"
    alt Cache Hit
        RDB-->>CS: Returns stored JSON string
        CS-->>CM: Returns parsed JSON object
    else Cache Miss
        RDB-->>CS: Returns null
        CS-->>CM: Returns null
    end
```
And if it's a cache miss, later the `cacheMiddleware` will tell `CacheService` to store the new result:
```mermaid
sequenceDiagram
    participant CM as cacheMiddleware
    participant CS as CacheService
    participant RDB as Redis Database

    Note over CM: Controller generates response data
    CM->>CS: set("pdf-{...request_body...}", responseData, expiryTime)
    CS->>RDB: SET "pdf-{...request_body...}" "jsonDataString" EX expiryTime
    RDB-->>CS: "OK"
    CS-->>CM: true (success)
```

Now, let's look at simplified snippets from `src/services/cacheService.js`:

**1. Setting up the Connection (Constructor):**
When `CacheService` is created, it connects to the Redis server. The Redis server's address and other settings come from our [Configuration Management](06_configuration_management_.md).

```javascript
// --- File: src/services/cacheService.js (constructor snippet) ---
const Redis = require('ioredis'); // A popular Redis client library
const config = require('../config/config'); // For Redis URL and TTL
const logger = require('../utils/logger');

class CacheService {
  constructor() {
    // 1. Connect to Redis using URL from config
    this.redisClient = new Redis(config.redis.url, { /* ...retry options... */ });
    this.isConnected = false;

    // 2. Listen to connection events
    this.redisClient.on('connect', () => logger.info('Redis: Connected'));
    this.redisClient.on('ready', () => { this.isConnected = true; /* ... */ });
    this.redisClient.on('error', (err) => { this.isConnected = false; /* ... */});
  }
  // ... other methods: get, set, del ...
}
```
1.  `new Redis(config.redis.url, ...)`: This line creates a Redis client instance and tells it where to find the Redis server (e.g., `redis://localhost:6379`). The `config.redis.url` is loaded from environment variables or a config file, managed by our [Configuration Management](06_configuration_management_.md).
2.  Event listeners (`on('connect')`, `on('ready')`, `on('error')`) help us track the connection status to Redis and log information.

**2. Getting Data from Cache (`get` method):**
This method retrieves a value from Redis based on a key.

```javascript
// --- File: src/services/cacheService.js (get method snippet) ---
class CacheService {
  // ... constructor ...
  async get(key) {
    try {
      if (!this.isConnected) return null; // Don't try if not connected

      const value = await this.redisClient.get(key); // 1. Ask Redis for key
      if (value) {
        return JSON.parse(value); // 2. Parse if found (we store JSON)
      }
      return null; // Not found
    } catch (error) {
      logger.error(`Redis get error for key ${key}:`, error);
      return null; // Return null on error
    }
  }
  // ... set method ...
}
```
1.  `await this.redisClient.get(key)`: This sends a `GET` command to Redis. If the key exists, Redis sends back its value (as a string).
2.  `JSON.parse(value)`: Since we store JSON objects as strings in Redis, we need to parse the string back into a JavaScript object before returning it.

**3. Storing Data in Cache (`set` method):**
This method stores a key-value pair in Redis, with an expiry time (TTL).

```javascript
// --- File: src/services/cacheService.js (set method snippet) ---
class CacheService {
  // ... constructor, get method ...
  async set(key, value, expirySeconds = config.redis.ttl) { // 1. Default TTL
    try {
      if (!this.isConnected) return false;

      // 2. Store stringified JSON with expiry
      await this.redisClient.set(
        key,
        JSON.stringify(value), // Store as JSON string
        'EX', expirySeconds    // 'EX' means expiry in seconds
      );
      return true;
    } catch (error) {
      logger.error(`Redis set error for key ${key}:`, error);
      return false;
    }
  }
  // ... other methods ...
}
module.exports = new CacheService(); // Export an instance
```
1.  `expirySeconds = config.redis.ttl`: The `expirySeconds` parameter determines how long the item stays in the cache. It defaults to `config.redis.ttl`, which is loaded from our [Configuration Management](06_configuration_management_.md) (e.g., 300 seconds = 5 minutes).
2.  `await this.redisClient.set(key, JSON.stringify(value), 'EX', expirySeconds)`:
    *   Sends a `SET` command to Redis.
    *   `JSON.stringify(value)`: We convert the JavaScript `value` (our JSON response data) into a string because Redis stores strings.
    *   `'EX', expirySeconds`: This tells Redis to automatically delete this key after `expirySeconds` have passed.

By using this `CacheService`, our `cacheMiddleware` can easily check for existing results and store new ones, significantly speeding up responses for repeated, identical requests.

## Conclusion

You've now explored the **Caching Service** and how it dramatically improves the performance and efficiency of our `html-to-pdf-service`. You've learned:
*   Caching stores recent results to avoid redundant work.
*   **Redis** acts as our fast, in-memory cache.
*   A `cacheMiddleware` intercepts requests, checks the cache using a unique `cacheKey`, and serves from the cache if possible (a "cache hit").
*   If it's a "cache miss," the request proceeds, and the new result is then stored in the cache with an expiry time (TTL).
*   The `CacheService` handles the direct communication with Redis for getting and setting cached data.

This caching layer is crucial for making our service responsive and scalable, especially under heavy load.

But how are all these settings, like the Redis URL, the cache TTL, or the Google Cloud Storage bucket name, managed? We don't want to hardcode them! In the next chapter, we'll dive into [Chapter 6: Configuration Management](06_configuration_management_.md) to see how our application handles different settings for different environments.

---

Generated By NOVA