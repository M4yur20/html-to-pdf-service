# Chapter 1: Application Server & Middleware Pipeline

Welcome to the `html-to-pdf-service` project! This tutorial will guide you through its core components. In this first chapter, we'll explore the very foundation of our service: the **Application Server and Middleware Pipeline**.

## What's the Big Deal? The Problem We're Solving

Imagine you're building a popular online service that converts HTML web pages into PDF files. People from all over the world will send requests to your service.
*   How does your service actually "listen" for these requests from the internet?
*   Once a request arrives, how do you make sure it's safe and not trying to break your service?
*   How do you check if the request has all the information needed?
*   What if too many requests come in at once?

Handling all this for every single request, before you even *start* the main job (like converting HTML to PDF), can get complicated. The **Application Server and Middleware Pipeline** is designed to solve these problems by creating an organized and efficient way to process incoming requests.

Think of it like an assembly line in a factory:
1.  **Raw materials (web requests)** arrive.
2.  They pass through various **stations (middleware)**. Each station performs a specific task:
    *   One station might check for security.
    *   Another might parse the data to make it easier to use.
    *   A third might check if the user is sending too many requests (rate limiting).
3.  Only after passing through these preparation and validation stations does the request reach the main part of the factory where the actual work (like PDF generation) happens.

This "assembly line" ensures every request is handled consistently, securely, and efficiently.

## Key Concepts: Server and its Helpers

Let's break down the main ideas:

1.  **Application Server (Express.js):**
    *   This is the core engine of our web service. It's a program that's constantly running, listening for incoming network connections (HTTP requests).
    *   In our project, we use **Express.js**, which is a very popular and flexible framework for building web applications with Node.js (JavaScript on the server).
    *   **Analogy:** The application server is like the main receptionist at a very busy office. It's the first point of contact for all incoming messages (requests).

2.  **Middleware:**
    *   These are special functions that have access to the incoming request, the outgoing response, and a way to pass control to the next middleware in line.
    *   Each middleware typically performs a single, focused task.
    *   **Analogy:** Middleware functions are like specialized clerks or security guards in the office lobby.
        *   One clerk might check the sender's ID (authentication).
        *   A security guard might scan the package for dangerous items (security checks).
        *   Another clerk might translate the message into a standard format (data parsing).

3.  **Middleware Pipeline:**
    *   This is the sequence or "chain" of middleware functions that a request goes through.
    *   When a request arrives, Express.js passes it to the first middleware. That middleware does its job and then (usually) calls `next()` to pass the request to the next middleware in the pipeline, and so on.
    *   **Analogy:** The pipeline is the specific order in which visitors must see the clerks and guards in the lobby before reaching their final destination.

## How It Works: A Request's Journey

Let's see how an incoming request to convert HTML to PDF travels through our system.

1.  A user sends an HTTP request to our service's URL.
2.  Our **Application Server (Express.js)**, which is constantly listening, picks up this request.
3.  The server then sends the request through the **Middleware Pipeline**, one middleware at a time.

Here's a simplified look at what happens in `server.js`:

```javascript
// server.js (simplified)
const express = require('express');
const helmet = require('helmet');
// ... other imports

const app = express(); // 1. Create the application server

// 2. Add middleware "stations" to the pipeline
app.use(helmet()); // For basic security
app.use(express.json()); // To understand JSON data in requests
// ... other middleware like CORS, rate limiting, etc.

// 3. Define where requests go after middleware (Routes)
// app.use('/api/pdf', pdfRoutes); // Covered in Chapter 2

// 4. Special middleware for handling errors
// app.use(errorHandler);

// 5. Start the server listening for requests
app.listen(3000, () => {
  console.log('Server running on port 3000');
});
```

*   **`const app = express();`**: This line creates our Express application server. Think of it as building the main factory building.
*   **`app.use(...)`**: Each time we use `app.use()`, we're adding another "station" (middleware) to our assembly line. The order matters! Requests will go through them in the order they are added.
    *   `app.use(helmet());`: Adds a middleware called `helmet` that helps secure our app by setting various HTTP headers. It's like the first security checkpoint.
    *   `app.use(express.json());`: Adds a built-in Express middleware that parses incoming requests with JSON payloads (a common way to send data). This station makes sure the data is in a usable format.
*   **`app.listen(...)`**: This starts the server and makes it listen for incoming requests on a specific port (e.g., port 3000). The factory is now open for business!

So, before a request even gets to the logic that says "convert this HTML to PDF," it has already been checked, secured, and prepared by these middleware functions.

## Under the Hood: A Step-by-Step Flow

Let's visualize the journey of a request:

```mermaid
sequenceDiagram
    participant Client
    participant AppServer as Application Server (Express.js)
    participant MW1 as Security Middleware (Helmet)
    participant MW2 as JSON Parser Middleware
    participant MW3 as Rate Limiter Middleware
    participant RouteHandler as Specific Logic (e.g., PDF Conversion)

    Client->>AppServer: Sends HTTP Request (e.g., to generate a PDF)
    AppServer->>MW1: Request enters pipeline, hits Helmet
    MW1->>AppServer: Helmet processes, calls next()
    AppServer->>MW2: Request hits JSON Parser
    MW2->>AppServer: JSON Parser processes, calls next()
    AppServer->>MW3: Request hits Rate Limiter
    MW3->>AppServer: Rate Limiter checks, calls next()
    AppServer->>RouteHandler: Request reaches its destination logic
    RouteHandler->>AppServer: Logic prepares a Response
    AppServer->>Client: Sends HTTP Response
```

Each middleware function typically does its job and then calls a special function, often named `next()`, to pass the request along to the next middleware in the pipeline. If a middleware encounters a serious problem (e.g., a security issue or invalid data), it can choose to end the request-response cycle immediately, often by sending an error response.

### Diving Deeper into Code Examples

Let's look at how some of these middleware are set up in `server.js` and what they do.

**1. Basic Security with `helmet`:**

```javascript
// --- File: server.js ---
const helmet = require('helmet');
// ...
app.use(helmet());
```
This one line adds a collection of smaller middleware functions that set various HTTP headers to protect against common web vulnerabilities like Cross-Site Scripting (XSS) and clickjacking. It's an easy win for security!

**2. Parsing Request Data with `express.json`:**

```javascript
// --- File: server.js ---
// ...
app.use(express.json({ limit: '50mb' }));
```
When clients send data to your server (e.g., the HTML content to convert), they often send it in JSON format in the request body. This middleware parses that JSON string and makes it available in your code as a JavaScript object (usually `req.body`). The `limit: '50mb'` option increases the maximum size of the JSON payload it will accept.

**3. Preventing Abuse with Rate Limiting:**

```javascript
// --- File: server.js ---
const rateLimit = require('express-rate-limit');
// ...
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);
```
This middleware helps prevent abuse by limiting how many requests a single IP address can make within a certain time window (here, 100 requests per 15 minutes). If an IP exceeds this, subsequent requests might be blocked or delayed. This is crucial for service stability.

**4. Custom Input Validation (An Example Middleware):**

Sometimes, you need custom checks. Let's look at a snippet from `src/middleware/validation.js`. This middleware isn't directly for security or general parsing but for ensuring the specific data for PDF conversion is correct.

```javascript
// --- File: src/middleware/validation.js ---
// (Simplified for illustration)
// Joi is a library for data validation
const Joi = require('joi');

const convertSchema = Joi.object({ /* ... validation rules ... */ });

exports.validateConvertRequest = (req, res, next) => {
  const { error } = convertSchema.validate(req.body);
  if (error) {
    // If validation fails, send an error response
    return res.status(400).json({ error: error.details[0].message });
  }
  next(); // If validation passes, go to the next middleware/handler
};
```
This `validateConvertRequest` middleware would be used specifically for routes that handle PDF conversion. It checks if the `req.body` (the data sent by the client) matches the expected structure and rules defined in `convertSchema`. If not, it sends a `400 Bad Request` error. If everything is okay, it calls `next()` to proceed.

**5. Handling Errors Gracefully with `errorHandler`:**

What happens if an error occurs *anywhere* in the pipeline or in your main request handling logic? That's where a special error-handling middleware comes in. In Express, error-handling middleware have a distinct signature: `(err, req, res, next)`.

```javascript
// --- File: server.js ---
const errorHandler = require('./src/middleware/errorHandler');
// ...
// This is usually one of the LAST middleware added
app.use(errorHandler);
```

And a peek into `src/middleware/errorHandler.js`:
```javascript
// --- File: src/middleware/errorHandler.js ---
const logger = require('../utils/logger'); // For logging, see Chapter 7

module.exports = (err, req, res, next) => {
  logger.error('Error:', err.message); // Log the error

  const statusCode = err.status || 500; // Default to 500 Internal Server Error
  res.status(statusCode).json({
    error: { message: 'Something went wrong!' } // Send a generic error
  });
};
```
If any previous middleware calls `next(err)` (passing an error object), or if an error occurs in a route handler, Express will skip all other regular middleware and jump directly to this error-handling middleware. It then logs the error (using our [Observability (Logging & Health Checks)](07_observability__logging___health_checks__.md) system) and sends a standardized JSON error response to the client. This prevents scary stack traces from being sent to the user.

You'll notice other middleware in `server.js` like `compression` (to make responses smaller), `cors` (to allow requests from different domains), and `prometheusMiddleware` (for collecting metrics, part of [Observability (Logging & Health Checks)](07_observability__logging___health_checks__.md)). They all follow the same pattern: `app.use()` adds them to the pipeline, and they each perform a specific task on the request or response.

The `cacheMiddleware` from `src/middleware/cache.js` is another great example of a "station" that can significantly improve performance by serving previously generated PDFs from a [Caching Service](05_caching_service_.md) instead of regenerating them every time.

The port number `config.port` used in `app.listen(config.port, ...)` comes from our [Configuration Management](06_configuration_management_.md) setup, allowing us to easily change settings without modifying the core code.

## Conclusion

You've now learned about the foundational layer of our `html-to-pdf-service`: the **Application Server (Express.js) and the Middleware Pipeline**. You've seen how this "assembly line" approach helps us:
*   Listen for incoming web requests.
*   Process these requests through a series of checks and preparations (like security, data parsing, rate limiting, and validation).
*   Handle errors gracefully.

This structured approach ensures that by the time a request reaches the core logic of our application (like actually generating a PDF), it has already been vetted and prepared, making the rest of the application cleaner and more focused.

In the next chapter, we'll explore how, once a request has passed through the initial middleware, our application decides *what* specific code should handle it. Get ready to learn about [Request Routing & Controllers](02_request_routing___controllers_.md)!

---

Generated By NOVA