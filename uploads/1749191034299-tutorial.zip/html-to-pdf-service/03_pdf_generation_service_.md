# Chapter 3: PDF Generation Service

Welcome! In [Chapter 2: Request Routing & Controllers](02_request_routing___controllers_.md), we saw how an incoming request, like one to convert HTML to PDF, is routed to the correct `pdfController`. The controller then prepares to do the main job. But how does it *actually* turn that HTML into a PDF file? That's the job of our star for this chapter: the **PDF Generation Service**.

## What's the Big Deal? The Magic of Conversion

Imagine you've written a beautiful HTML page – maybe an invoice, a report, or a blog post. You want to share it as a PDF, which is a fixed format that looks the same everywhere. How do you make this conversion happen automatically within your application?

Manually opening a browser, loading the HTML, and printing to PDF for every request isn't practical for a web service. We need an automated, reliable "engine" that can take HTML (or a link to an HTML page) and spit out a PDF document.

This is exactly what the **PDF Generation Service** does. It's the core engine responsible for this conversion. Think of it as a highly skilled, automated typesetter and printer, all rolled into one.

## Key Concepts: The Engine and its Tools

Let's break down the main ideas behind our PDF Generation Service:

1.  **The Service Itself (The Engine):**
    *   This is a dedicated part of our application whose sole job is to create PDFs.
    *   It takes HTML content or a URL as input.
    *   It produces raw PDF data (called a "buffer") as output.
    *   **Analogy:** It's like a specialized printing press in our factory. You give it the manuscript (HTML), and it prints the books (PDFs).

2.  **Puppeteer (The Invisible Browser):**
    *   To convert HTML to PDF accurately, we need something that understands HTML, CSS, and JavaScript, just like a real web browser.
    *   Our service uses a powerful tool called **Puppeteer**. Puppeteer controls a headless (invisible) version of the Chrome/Chromium browser.
    *   **Analogy:** Puppeteer is like a robot arm that can open a web browser, type in a URL, wait for the page to load perfectly (with all styles and images), and then click the "Print to PDF" button, all without you seeing it on a screen.

3.  **Rendering HTML:**
    *   The invisible browser (Puppeteer) loads the HTML.
    *   Crucially, it *renders* the page. This means it processes all the HTML tags, applies CSS styles, loads images, and even runs JavaScript if needed, to make the page look exactly as it would in a normal browser.

4.  **"Printing" to PDF:**
    *   Once the page is fully rendered, Puppeteer instructs the browser to "print" the current view into a PDF format.
    *   This isn't like printing to paper; it creates a digital PDF file's data.

5.  **PDF Data (Buffer):**
    *   The output of this process is a "buffer" – a sequence of bytes representing the PDF file. This buffer can then be saved to a file, sent to a user, or stored in the cloud.

## How It Works: From HTML to PDF Data

Let's see the journey when the `pdfController` wants to generate a PDF.

1.  The `pdfController` (from [Chapter 2: Request Routing & Controllers](02_request_routing___controllers_.md)) has received a request with HTML content (or a URL).
2.  It calls a function within our `PdfService`, let's say `generatePdf(htmlContent, options)`.
3.  The `PdfService` then uses Puppeteer:
    *   It starts an invisible browser.
    *   It tells the browser to open a new page.
    *   It loads the provided HTML content (or navigates to the URL).
    *   It waits for the page to be fully rendered.
    *   It commands the browser to generate a PDF of the current page with specified options (like page size, orientation).
    *   It closes the browser.
4.  The `PdfService` gets back the PDF data (buffer) from Puppeteer.
5.  This PDF buffer is then returned to the `pdfController`.

The controller can then pass this PDF buffer to other services, for example, the [Cloud Storage Service](04_cloud_storage_service_.md) to save it, or it might be used by the [Caching Service](05_caching_service_.md).

### Using the PDF Service (Controller's View)

Let's look at how the `pdfController` (from `src/controllers/pdfController.js`) might use the `pdfService`. This snippet should look familiar from Chapter 2, but now we're focusing on the `pdfService` interaction.

```javascript
// --- File: src/controllers/pdfController.js (simplified snippet) ---
const pdfService = require('../services/pdfService'); // 1. Import the service
// ... other imports like storageService, logger

exports.convertToPdf = async (req, res, next) => {
  try {
    const { input, format, orientation } = req.body; // 2. Get user input

    // 3. Call the PDF service to generate the PDF
    const pdfBuffer = await pdfService.generatePdf(input, {
      format,
      orientation
    });

    // 4. Now pdfBuffer contains the PDF data.
    // Next, we'd usually upload it (e.g., to Cloud Storage Service)
    // and send back a URL.
    // For now, imagine:
    logger.info('PDF generated successfully!');
    res.send('PDF would be here!'); // Placeholder response

  } catch (error) {
    next(error);
  }
};
```

1.  **`require('../services/pdfService')`**: We import our `PdfService` so the controller can use its functions.
2.  **`const { input, format, orientation } = req.body;`**: The controller gets the HTML to convert (`input`) and any desired PDF options (like `format` e.g., 'A4', 'Letter', and `orientation` e.g., 'portrait', 'landscape') from the request.
3.  **`await pdfService.generatePdf(input, { format, orientation });`**: This is the key call!
    *   `input`: This can be a string of HTML code or a URL (e.g., "https://example.com").
    *   `{ format, orientation }`: An object with options for the PDF generation.
    *   The `await` keyword means the controller will pause here until the `pdfService` finishes generating the PDF and returns the `pdfBuffer`.
4.  **`pdfBuffer`**: This variable now holds the raw data of the generated PDF. It's not a file path yet, but the actual bytes of the PDF. This buffer is then ready to be processed further, often by the [Cloud Storage Service](04_cloud_storage_service_.md) to save it and get a shareable URL.

## Under the Hood: The Puppeteer Magic

So, what happens inside `pdfService.generatePdf()`? This is where Puppeteer steps in.

Let's visualize the internal flow:

```mermaid
sequenceDiagram
    participant Controller
    participant PdfService
    participant Puppeteer as Puppeteer (Browser)
    participant WebPage as Browser Page

    Controller->>PdfService: generatePdf(htmlOrUrl, options)
    PdfService->>Puppeteer: Launch browser instance
    Puppeteer-->>PdfService: Browser ready
    PdfService->>Puppeteer: Open new page
    Puppeteer-->>PdfService: New page ready (WebPage)
    alt HTML String Input
        PdfService->>WebPage: Set page content (HTML)
    else URL Input
        PdfService->>WebPage: Navigate to URL
    end
    WebPage-->>PdfService: Page loaded and rendered
    PdfService->>WebPage: Generate PDF (with options)
    WebPage-->>PdfService: PDF data (buffer)
    PdfService->>Puppeteer: Close browser
    PdfService-->>Controller: Return PDF data (buffer)
```

Now let's look at a simplified version of the code in `src/services/pdfService.js`:

```javascript
// --- File: src/services/pdfService.js (simplified) ---
const puppeteer = require('puppeteer');
const logger = require('../utils/logger'); // For logging

class PdfService {
  async generatePdf(input, options = {}) {
    let browser; // Declare browser here to access in finally
    try {
      // 1. Launch an invisible browser
      browser = await puppeteer.launch({
        executablePath: '/usr/bin/google-chrome', // Path to Chrome
        headless: 'new', // Run without a visible UI
        args: ['--no-sandbox'] // Common arguments for server environments
      });
      logger.info('Puppeteer browser launched.');

      // 2. Open a new blank page
      const page = await browser.newPage();
      logger.info('New page created in browser.');

      // 3. Load the HTML content
      if (input.startsWith('http')) {
        await page.goto(input, { waitUntil: 'networkidle0' }); // Load URL
        logger.info(`Navigated to URL: ${input}`);
      } else {
        await page.setContent(input, { waitUntil: 'networkidle0' }); // Load HTML string
        logger.info('Set HTML content directly.');
      }

      // Ensure styles like shadows are printed correctly
      await page.emulateMediaType('screen');

      // 4. "Print" the page to a PDF buffer
      const pdfBuffer = await page.pdf({
        format: options.format || 'A4',       // e.g., 'A4', 'Letter'
        printBackground: true,                // Include background colors/images
        landscape: options.orientation === 'landscape', // true for landscape
        // ... other options like scale, margins can be added
      });
      logger.info('PDF buffer generated.');

      return pdfBuffer; // Return the raw PDF data

    } catch (error) {
      logger.error('Error generating PDF with Puppeteer:', error);
      throw error; // Re-throw the error to be caught by the controller
    } finally {
      // 5. Always close the browser, even if errors occurred
      if (browser) {
        await browser.close();
        logger.info('Puppeteer browser closed.');
      }
    }
  }
}

module.exports = new PdfService();
```

Let's break this down step-by-step:

1.  **`puppeteer.launch(...)`**:
    *   This command starts a new instance of the Chromium browser.
    *   `executablePath`: Tells Puppeteer where to find the Chrome/Chromium executable. This is important for environments where Chrome isn't in a standard location.
    *   `headless: 'new'`: This is crucial. It means the browser runs in the background, without any visible windows. Perfect for a server!
    *   `args: ['--no-sandbox']`: These are command-line arguments passed to the browser. `--no-sandbox` is often required when running Puppeteer in restricted environments like Docker containers.

2.  **`browser.newPage()`**:
    *   Once the browser is running, this opens a new tab or page within that browser. All our interactions (loading HTML, printing) will happen on this `page` object.

3.  **Loading HTML**:
    *   `if (input.startsWith('http'))`: The service checks if the `input` is a URL.
    *   `await page.goto(input, { waitUntil: 'networkidle0' });`: If it's a URL, Puppeteer navigates the invisible page to that web address. `waitUntil: 'networkidle0'` tells Puppeteer to wait until the network activity on the page has calmed down, meaning images, scripts, and styles are likely fully loaded.
    *   `await page.setContent(input, { waitUntil: 'networkidle0' });`: If `input` is not a URL, it's assumed to be a string of HTML code. `page.setContent` directly loads this HTML into the page.
    *   `await page.emulateMediaType('screen');`: This little trick tells the browser to render the page as it would for a screen, which helps ensure things like CSS `box-shadow` are included in the PDF. By default, printing often uses a 'print' media type which might hide some visual elements.

4.  **`page.pdf(...)`**:
    *   This is the magic command! It tells Puppeteer to take the currently rendered page and convert it into PDF data.
    *   We can pass many options:
        *   `format: options.format || 'A4'`: Sets the page size (e.g., 'A4', 'Letter'). It uses the `format` from the `options` object if provided, otherwise defaults to 'A4'.
        *   `printBackground: true`: Ensures that background colors and images from the HTML/CSS are included in the PDF.
        *   `landscape: options.orientation === 'landscape'`: Sets the page orientation. If `options.orientation` is 'landscape', this will be `true`.
        *   Many other options exist for margins, scale, page ranges, etc. These can be configured through our [Configuration Management](06_configuration_management_.md).

5.  **`finally { if (browser) { await browser.close(); } }`**:
    *   This is very important! The `finally` block ensures that the browser instance is closed, whether the PDF generation was successful or an error occurred.
    *   Leaving browser instances running can consume a lot of server resources. Closing them cleans up properly.

The `pdfBuffer` returned by this function is the raw binary data of the PDF. It's not yet a file on the server's disk, but it's ready to be saved or sent.

## Conclusion

You've now dived into the heart of our `html-to-pdf-service`: the **PDF Generation Service**. You've learned:
*   It's the engine that converts HTML (or URLs) into PDF documents.
*   It uses **Puppeteer** to control an invisible browser, ensuring accurate rendering of web content.
*   The process involves launching a browser, loading content, rendering it, and then "printing" it to a PDF data buffer.
*   This PDF buffer can then be handled by other parts of our application.

This service is a critical component, taking the raw material (HTML) and transforming it into the desired product (PDF). But what happens to this PDF data once it's created? How do we store it and make it accessible to users?

That's where our next chapter comes in. We'll explore how we take the `pdfBuffer` and save it persistently using the [Chapter 4: Cloud Storage Service](04_cloud_storage_service_.md).

---

Generated By NOVA